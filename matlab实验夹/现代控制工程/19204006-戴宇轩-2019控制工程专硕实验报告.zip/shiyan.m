A = [0 , 1;-0.21 , -1];
B = [1 ; 1];
u = 'z/(z - 1)';
[Ak ,AkBu] = disolve(A ,B ,u);
X0 = [1 ; -1];
xk = Ak * X0 + AkBu